import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators, FormArray } from '@angular/forms';
import { ReactiveFormsModule, FormGroup } from '@angular/forms';
import { ApiService } from '../../../api.service';
import { Person } from '../../../shared/TransferObjects/Person';

@Component({
  selector: 'app-edit-person',
  templateUrl: './edit-person.component.html'
})
export class EditPersonComponent implements OnInit {

  model: Person;

  personEditForm: FormGroup =  // Initialize form fields to null
  this.formBuilder.group({
    personID: [null, Validators.required],
    firstName: [null, [Validators.required, Validators.maxLength(150)]],
    lastName: [null, [Validators.required, Validators.maxLength(150)]],
    age: [null, [Validators.required, Validators.max(120)]],
    color: [null, [Validators.required, Validators.maxLength(150)]],
    hobbies: this.formBuilder.array([])
  });

  constructor(private formBuilder: FormBuilder,
    private apiService: ApiService,
    private route: ActivatedRoute,
    private router: Router) {
    this.route.params.subscribe(params => this.setPerson(params['personID']));
  }

  ngOnInit(): void {
  }

  setPerson(personID: number) {
    this.apiService.getPerson(personID).subscribe((data: Person) => {
      this.model = data;
      this.personEditForm.patchValue({personID: this.model.personID});
      this.personEditForm.patchValue({firstName: this.model.firstName});
      this.personEditForm.patchValue({lastName: this.model.lastName});
      this.personEditForm.patchValue({age: this.model.age});
      this.personEditForm.patchValue({color: this.model.color});
      for (const hobby of this.model.hobbies) {
        this.hobbies.push(this.formBuilder.control(hobby));
      }
    });
  }
  onSubmit(): void {
    this.apiService.modifyPerson(this.personEditForm.value).subscribe();
    this.router.navigate(['summary', {
      queryParams: { refresh: new Date().getTime() }
    }]);
  }

  deletePerson(): void {
    this.apiService.deletePerson(this.personEditForm.value.personID).subscribe();
    this.router.navigate(['summary', {
      queryParams: { refresh: new Date().getTime() }
    }]);
  }
  get f() { return this.personEditForm.controls; }

  get hobbies() {
    return this.personEditForm.get('hobbies') as FormArray;
  }

  addHobby() {
    this.hobbies.push(this.formBuilder.control(''));
  }
  deleteHobby(index) {
    this.hobbies.removeAt(index);
  }
}
