import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { Person } from '../shared/TransferObjects/Person';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material/table';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit {

  persons: Array<Person>;
  displayedColumns: string[] = ['select', 'FirstName', 'LastName', 'Age', 'Color', 'Hobbies'];

  dataSource = new MatTableDataSource<Person>();
  selection = new SelectionModel<Person>(true, []);

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: Person): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.personID + 1}`;
  }

  constructor(private apiService: ApiService, private router: Router) {
  }

  ngOnInit(): void {
    this.apiService.get().subscribe((data: Person[]) => {
      this.persons = data;
      this.dataSource = new MatTableDataSource<Person>(data);
    });
  }

  editDetails(data: Person) {
    this.router.navigate(['person-edit/', data.personID]);
  }

  deleteRecordsSelected() {
    this.selection.selected.forEach(row => {
      this.apiService.deletePerson(row.personID).subscribe();
    });
  }
}
