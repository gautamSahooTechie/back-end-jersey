import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SummaryComponent } from './summary/summary.component';
import { PersonComponent } from './person/person.component';
import { EditPersonComponent } from './person/edit/edit-person/edit-person.component';

const routes: Routes = [
  { path: '', redirectTo: 'summary', pathMatch: 'full'},
  { path: 'summary', component: SummaryComponent },
  { path: 'person', component: PersonComponent },
  { path: 'person-edit/:personID', component: EditPersonComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
