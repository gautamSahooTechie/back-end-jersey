import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { Person } from './shared/TransferObjects/Person';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  private SERVER_URL = 'http://localhost:8080/bl-services/rest/people/summary';

  private SERVER_PERSON = 'http://localhost:8080/bl-services/rest/person';

  constructor(private httpClient: HttpClient) { }

  public get() {
    return this.httpClient.get(this.SERVER_URL).pipe(catchError(this.handleError));
  }

  public getPerson(personID: number) {
    return this.httpClient.get(this.SERVER_PERSON + '/' + personID).pipe(catchError(this.handleError));
  }

  public deletePerson(personID: number) {
    return this.httpClient.delete(this.SERVER_PERSON + '/' + personID).pipe(catchError(this.handleError));
  }

  public savePerson(person: Person) {
    return this.httpClient.post(this.SERVER_PERSON , person).pipe(catchError(this.handleError));
  }

  public modifyPerson(person: Person) {
    return this.httpClient.put(this.SERVER_PERSON , person).pipe(catchError(this.handleError));
  }

  handleError(error: HttpErrorResponse) {
    let errorMessage = 'Unknown error!';
    if (error.error instanceof ErrorEvent) {
      // Client-side errors
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side errors
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }
}
