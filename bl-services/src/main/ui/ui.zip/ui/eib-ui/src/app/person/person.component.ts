import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators, FormArray } from '@angular/forms';
import { ReactiveFormsModule, FormGroup } from '@angular/forms';
import { Person } from '../shared/TransferObjects/Person';
import { ApiService } from '../api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-person',
  templateUrl: './person.component.html'
})
export class PersonComponent implements OnInit {
  model: Person;

  personForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private apiService: ApiService, private router: Router) {
  }

  ngOnInit(): void {
    // Initialize form fields to null
    this.personForm = this.formBuilder.group({
      firstName: [null, [Validators.required, Validators.maxLength(150)]],
      lastName: [null, [Validators.required, Validators.maxLength(150)]],
      age: [null, [Validators.required, Validators.max(120)]],
      color: [null, [Validators.required, Validators.maxLength(150)]],
      hobbies: this.formBuilder.array([])
    });
  }
  // convenience getter for easy access to form fields
  get f() { return this.personForm.controls; }

  get hobbies() {
    return this.personForm.get('hobbies') as FormArray;
  }

  addHobby() {
    this.hobbies.push(this.formBuilder.control(''));
  }
  deleteHobby(index) {
    this.hobbies.removeAt(index);
  }

  onSubmit(): void {
    console.log(this.personForm.value);
    this.apiService.savePerson(this.personForm.value).subscribe();
    this.router.navigate(['summary', {
      queryParams: { refresh: new Date().getTime() }
    }]);
  }
}
