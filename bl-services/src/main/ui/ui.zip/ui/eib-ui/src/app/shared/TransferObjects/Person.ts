export interface Person {
    personID: number;
    firstName: string;
    lastName: string;
    age: number;
    color: string;
    hobbies?: Array<string>;
  }
